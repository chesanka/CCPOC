package com.david.ICFS.process;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.david.ICFS.dao.ICFSSPjdbc;
import com.david.ICFS.po.ICFSSP2Result;

public class CallSPProcess {	
	
	public List<ICFSSP2Result> getICFSSP2ResultFromRS(){
		ICFSSPjdbc icfsjdbc = new ICFSSPjdbc();
		CallableStatement stmt = icfsjdbc.getCallICFSUSProfileStatement();
		List<ICFSSP2Result> list = new ArrayList<ICFSSP2Result>();
		java.sql.ResultSet rs = null;
		try {
		stmt.registerOutParameter(1, Types.INTEGER);
		stmt.execute();
		int sqlCode = stmt.getInt(1);
		rs = stmt.getResultSet();
		if(rs!=null&&sqlCode==0) {
		while(rs.next()) {
		ICFSSP2Result result = new ICFSSP2Result();
		String finEnterpNum = rs.getString(1);
		String finInstrNum = rs.getString(2);
		String origTransType = rs.getString(3);
		String contrNum = rs.getString(4);
		String effDte = rs.getString(5);
		String transType = rs.getString(6);
		String currCode = rs.getString(7);
		String machType = rs.getString(8);
		String machMod = rs.getString(9);
		String machSerNum = rs.getString(10);
		String mesNum = rs.getString(11);
		String custNum = rs.getString(12);
		
		result.setfinEnterpNum(finEnterpNum);
		result.setfinInstrNum(finInstrNum);
		result.setorigTransType(origTransType);
		result.setcontrNum(contrNum);
		result.seteffDte(effDte);
		result.settransType(transType);
		result.setcurrCode(currCode);
		result.setmachType(machType);
		result.setmachMod(machMod);
		result.setmachSerNum(machSerNum);
		result.setmesNum(mesNum);
		result.setcustNum(custNum);
		list.add(result); }
		} 
		}
		catch (SQLException e) {
		e.printStackTrace();
		}
		return list;
		}
}