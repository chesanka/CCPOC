package com.david.ICFS.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ICFSSPjdbc {

	public ICFSSPjdbc(){
		
	}
	
	public Connection getICFSUSConnection(){
		Connection conn = null;
		ResourceBundle icfssp = ResourceBundle.getBundle("icfssp");
		String url = icfssp.getString("icfs.us.url");
		String userid = icfssp.getString("icfs.us.userid");
		String pwd = icfssp.getString("icfs.us.password");
		System.out.println(url + userid + pwd);
		try {
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			conn = DriverManager.getConnection(url, userid, pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	public CallableStatement getCallICFSUSProfileStatement(){
		CallableStatement stmt = null;
		Connection conn = null;
		ResourceBundle icfssp = ResourceBundle.getBundle("icfssp");
		String sql = icfssp.getString("icfs.us.callprofilesql");
		try {
			conn = getICFSUSConnection();
			stmt = conn.prepareCall(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return stmt;
	}
	
	public static void main(String[] args) {
		ICFSSPjdbc icfsjdbc = new ICFSSPjdbc();
		Connection conn = icfsjdbc.getICFSUSConnection();
		try {
			System.out.println(conn.getHoldability());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
