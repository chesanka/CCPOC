package com.david.ICFS.po;

public class ICFSSP2Result {
	private String finEnterpNum;
	private String finInstrNum;
	private String origTransType;
	private String contrNum;
	private String effDte;
	private String transType;
	private String currCode;
	private String machType;
	private String machMod;
	private String machSerNum;
	private String mesNum;
	private String custNum;
	private String result;
	
	
	
	public String getfinEnterpNum() {
		return finEnterpNum;
	}
	public void setfinEnterpNum(String finEnterpNum) {
		this.finEnterpNum = finEnterpNum;
	}
	public String getfinInstrNum() {
		return finInstrNum;
	}
	public void setfinInstrNum(String finInstrNum) {
		this.finInstrNum = finInstrNum;
	}
	public String getorigTransType() {
		return origTransType;
	}
	public void setorigTransType(String origTransType) {
		this.origTransType = origTransType;
	}
	public String getcontrNum() {
		return contrNum;
	}
	public void setcontrNum(String contrNum) {
		this.contrNum = contrNum;
	}
	public String geteffDte() {
		return effDte;
	}
	public void seteffDte(String effDte) {
		this.effDte = effDte;
	}
	public String gettransType() {
		return transType;
	}
	public void settransType(String transType) {
		this.transType = transType;
	}
	public String getcurrCode() {
		return currCode;
	}
	public void setcurrCode(String currCode) {
		this.currCode = currCode;
	}
	public String getmachType() {
		return machType;
	}
	public void setmachType(String machType) {
		this.machType = machType;
	}
	public String getmachMod() {
		return machMod;
	}
	public void setmachMod(String machMod) {
		this.machMod = machMod;
	}
	public String getmachSerNum() {
		return machSerNum;
	}
	public void setmachSerNum(String machSerNum) {
		this.machSerNum = machSerNum;
	}
	public String getmesNum() {
		return mesNum;
	}
	public void setmesNum(String mesNum) {
		this.mesNum = mesNum;
	}
	public String getcustNum() {
		return custNum;
	}
	public void setcustNum(String custNum) {
		this.custNum = custNum;
	}

	public String result() {
		return result;
	}
	public void setresult(String result) {
		this.result = result;
		
	}
	public void add(ICFSSP2Result result) {
		
	}
	
}
